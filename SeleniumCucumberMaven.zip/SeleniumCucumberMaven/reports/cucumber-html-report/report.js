$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("basket.feature");
formatter.feature({
  "line": 2,
  "name": "Validate text create account",
  "description": "",
  "id": "validate-text-create-account",
  "keyword": "Feature",
  "tags": [
    {
      "line": 1,
      "name": "@run"
    }
  ]
});
formatter.scenario({
  "comments": [
    {
      "line": 3,
      "value": "#Create account features"
    }
  ],
  "line": 5,
  "name": "Validate Create Account",
  "description": "",
  "id": "validate-text-create-account;validate-create-account",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 6,
  "name": "Go to Amazon.com",
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "Search for Samsung Galaxy S9 - store the price",
  "keyword": "When "
});
formatter.step({
  "line": 8,
  "name": "Click on the First Result",
  "keyword": "Then "
});
formatter.step({
  "line": 9,
  "name": "Once in the details page compare this price vs the above one",
  "keyword": "Then "
});
formatter.step({
  "line": 10,
  "name": "Click on Add to Cart",
  "keyword": "Then "
});
formatter.step({
  "line": 11,
  "name": "Go to Amazon main page",
  "keyword": "Then "
});
formatter.step({
  "line": 12,
  "name": "Click on \"Your Amazon.com\" button",
  "keyword": "Then "
});
formatter.step({
  "line": 13,
  "name": "Click on \"Create Your Amazon Account\"",
  "keyword": "Then "
});
formatter.step({
  "line": 14,
  "name": "Fill all the fields and do not click on Create your Amazon account button",
  "keyword": "Then "
});
formatter.step({
  "line": 15,
  "name": "Validate that the text is preset: \"Create account\"",
  "keyword": "Then "
});
formatter.match({
  "location": "Amazon.go_to_Amazon_com()"
});
formatter.result({
  "duration": 31669881510,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "9",
      "offset": 27
    }
  ],
  "location": "Amazon.search_for_Samsung_Galaxy_S_store_the_price(int)"
});
formatter.result({
  "duration": 15117065384,
  "status": "passed"
});
formatter.match({
  "location": "Amazon.click_on_the_First_Result()"
});
formatter.result({
  "duration": 8071267931,
  "status": "passed"
});
formatter.match({
  "location": "Amazon.once_in_the_details_page_compare_this_price_vs_the_above_one()"
});
formatter.result({
  "duration": 42885914,
  "status": "passed"
});
formatter.match({
  "location": "Amazon.click_on_Add_to_Cart()"
});
formatter.result({
  "duration": 2102035264,
  "status": "passed"
});
formatter.match({
  "location": "Amazon.go_to_Amazon_main_page()"
});
formatter.result({
  "duration": 1277061513,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Your Amazon.com",
      "offset": 10
    }
  ],
  "location": "Amazon.click_on_button(String)"
});
formatter.result({
  "duration": 3052678233,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Create Your Amazon Account",
      "offset": 10
    }
  ],
  "location": "Amazon.click_on(String)"
});
formatter.result({
  "duration": 654537573,
  "status": "passed"
});
formatter.match({
  "location": "Amazon.fill_all_the_fields_and_do_not_click_on_Create_your_Amazon_account_button()"
});
formatter.result({
  "duration": 458369971,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Create account",
      "offset": 35
    }
  ],
  "location": "Amazon.validate_that_the_text_is_preset(String)"
});
formatter.result({
  "duration": 32233769,
  "status": "passed"
});
});