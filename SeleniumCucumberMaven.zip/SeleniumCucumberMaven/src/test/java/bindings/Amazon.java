package bindings;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;

import org.apache.commons.exec.environment.EnvironmentUtils;
import org.omg.CORBA.Environment;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import AutomationBase.Automationbase;
import POM.ObjectRepository;

import java.util.List;
import java.util.concurrent.TimeUnit;
import static org.junit.Assert.assertTrue;

public class Amazon extends Automationbase{
	WebDriver driver;
	double Myprice;
	double DetailPrice;
	 private String webSite = "https://www.amazon.com";
	
	 @Override
	 public String getWebSite() {
	 return webSite;
	 }
	
	 @Override
	 public void  beforeTest() {
	 
	 }
	 
	@Given("^Go to Amazon\\.com$")
	public void go_to_Amazon_com() throws Throwable {
		String DriverPath = System.getProperty("user.dir") + "\\src\\Driver\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", DriverPath);
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get("https://www.amazon.com");
	}

	@When("^Search for Samsung Galaxy S(\\d+) - store the price$")
	public void search_for_Samsung_Galaxy_S_store_the_price(int arg1) throws Throwable {
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		ObjectRepository.SearchTextbox(driver).sendKeys("Samsung Galaxy S9");
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		ObjectRepository.SearchButton(driver).click();
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,800)");
		String price = driver.findElement(By.xpath(
				"//*[@id=\"search\"]/div[1]/div[2]/div/span[3]/div[1]/div[2]/div/span/div/div/div[2]/div[2]/div/div[2]/div[1]/div/div[1]/div"))
				.getText();
		String finalPrice[] = price.split("\\r?\\n");
		Myprice = Double.parseDouble(finalPrice[0].substring(1, finalPrice[0].length()) + "." + finalPrice[1]);

	}

	@Then("^Click on the First Result$")
	public void click_on_the_First_Result() throws Throwable {

		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		ObjectRepository.FirstResult(driver).click();

	}

	@Then("^Once in the details page compare this price vs the above one$")
	public void once_in_the_details_page_compare_this_price_vs_the_above_one() throws Throwable {

		String DetailsPrice = driver.findElement(By.xpath("//*[@id=\"priceblock_ourprice\"]")).getText();
		DetailPrice = Double.parseDouble(DetailsPrice.substring(1, DetailsPrice.length()));

		if (Myprice == DetailPrice) {
			System.out.println("Listing price and details price match!");

			System.out.println("Listing price is : " + Myprice);
			System.out.println("Details price is : " + DetailPrice);
		} else {
			System.out.println("Listing price and details price are not match!");
		}

	}

	@Then("^Click on Add to Cart$")
	public void click_on_Add_to_Cart() throws Throwable {
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		ObjectRepository.AddToBasket(driver).click();
	}

	@Then("^Go to Amazon main page$")
	public void go_to_Amazon_main_page() throws Throwable {
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		ObjectRepository.NavigateAmazoneMainPage(driver).click();
	}

	@Then("^Click on \"([^\"]*)\" button$")
	public void click_on_button(String arg1) throws Throwable {
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		ObjectRepository.ClickOnAmazoneMainPage(driver).click();
	}

	@Then("^Click on \"([^\"]*)\"$")
	public void click_on(String arg1) throws Throwable {
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		ObjectRepository.ClickOnCreateYourAmazoneAccount(driver).click();
	}

	@Then("^Fill all the fields and do not click on Create your Amazon account button$")
	public void fill_all_the_fields_and_do_not_click_on_Create_your_Amazon_account_button() throws Throwable {
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		ObjectRepository.UsernameTxt(driver).sendKeys("Test Amazone User");
		ObjectRepository.UserEmailTxt(driver).sendKeys("TestAmazone@gmail.com");
		ObjectRepository.PasswordTxt(driver).sendKeys("Test@123");
		ObjectRepository.ConfirmPasswordTxt(driver).sendKeys("Test@123");
	}

	@Then("^Validate that the text is preset: \"([^\"]*)\"$")
	public void validate_that_the_text_is_preset(String arg1) throws Throwable {
		String ActualResult = driver.findElement(By.xpath("//*[@id=\"ap_register_form\"]/div/div/h1")).getText();

		System.out.println("Expected Result is : Create account");
		Assert.assertEquals("Create account", ActualResult);
		System.out.println("Actual Result is :" + ActualResult);
	}
	
	@Override
	public void afterTest() {}
}