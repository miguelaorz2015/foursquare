package POM;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class ObjectRepository {

	private static WebElement element = null;

	public static WebElement SearchTextbox(WebDriver driver) {

		element = driver.findElement(By.xpath("//*[@id=\"twotabsearchtextbox\"]"));

		return element;

	}

	public static WebElement SearchButton(WebDriver driver) {

		element = driver.findElement(By.xpath("//*[@id=\"nav-search\"]/form/div[2]/div"));

		return element;

	}

	public static WebElement FirstResult(WebDriver driver) {

		element = driver.findElement(By.xpath(
				"//*[@id=\"search\"]/div[1]/div[2]/div/span[3]/div[1]/div[1]/div/span/div/div/div[2]/div[2]/div/div[1]/div/div/div[1]/h2/a/span"));

		return element;

	}

	public static WebElement AddToBasket(WebDriver driver) {

		element = driver.findElement(By.xpath("//*[@id=\"add-to-cart-button\"]"));

		return element;

	}

	public static WebElement NavigateAmazoneMainPage(WebDriver driver) {

		element = driver.findElement(By.xpath("//*[@id=\"nav-logo\"]/a"));

		return element;

	}

	public static WebElement ClickOnAmazoneMainPage(WebDriver driver) {

		element = driver.findElement(By.xpath("//*[@id=\"nav-your-amazon\"]"));

		return element;

	}

	public static WebElement ClickOnCreateYourAmazoneAccount(WebDriver driver) {

		element = driver.findElement(By.xpath("//*[@id=\"auth-create-account-link\"]"));

		return element;

	}

	public static WebElement UsernameTxt(WebDriver driver) {

		element = driver.findElement(By.xpath("//*[@id=\"ap_customer_name\"]"));

		return element;

	}

	public static WebElement UserEmailTxt(WebDriver driver) {

		element = driver.findElement(By.xpath("//*[@id=\"ap_email\"]"));

		return element;

	}

	public static WebElement PasswordTxt(WebDriver driver) {

		element = driver.findElement(By.xpath("//*[@id=\"ap_password\"]"));

		return element;

	}

	public static WebElement ConfirmPasswordTxt(WebDriver driver) {

		element = driver.findElement(By.xpath("//*[@id=\"ap_password_check\"]"));

		return element;

	}

}
