package AutomationBase;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.os.WindowsUtils;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

public abstract class Automationbase {

	public WebDriver driver;
	private String webSite;
	public WindowsUtils wait;

	public String getWebSite() {
		return webSite;
	}

	@BeforeTest
	public void beforeTest() {
		String webDriverKey = "webdriver.chrome.driver";
		String DriverPath = System.getProperty("user.dir") + "\\src\\Driver\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", DriverPath);
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		wait = new WindowsUtils();
		driver.navigate().to(getWebSite());
		driver.manage().window().maximize();
	}

	@AfterTest
	public void afterTest() {
		driver.quit();
	}

}
